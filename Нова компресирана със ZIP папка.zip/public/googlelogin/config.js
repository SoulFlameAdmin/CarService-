// public/googlelogin/config.js
export const SF_GOOGLE_MAPS_KEY = "PASTE_YOUR_KEY_HERE";
