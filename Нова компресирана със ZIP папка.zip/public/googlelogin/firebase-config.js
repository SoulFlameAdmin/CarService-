// E:\SOULFLAME_v1\CarService\public\googlelogin\firebase-config.js
export const firebaseConfig = {
  apiKey: "AIzaSyBXHmnZdqgMsxB_BmjH1ceBWPCGWgGE4NA",
  authDomain: "bgserveces.firebaseapp.com",
  projectId: "bgserveces",
  storageBucket: "bgserveces.firebasestorage.app",
  messagingSenderId: "1013064335760",
  appId: "1:1013064335760:web:ec575dce44045415957315",
  measurementId: "G-662DNT318N"
};
