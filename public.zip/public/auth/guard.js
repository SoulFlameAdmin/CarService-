import { watchAuth } from "./auth.js";

export function requireAuthOrRedirect(loginPage){
}

export function redirectIfLoggedIn(nextPage){
}
